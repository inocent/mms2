# Methods []({{ site.repo }}/blob/master/docs/_i18n/{{ site.lang }}/examples/methods.md)

---

## Reset View

El encabezado de la tabla no se ajusta automáticamente, se necesita llamar al método `resetView`. _by [@wenzhixin](https://github.com/wenzhixin)_

<iframe width="100%" height="300" data-src="http://jsfiddle.net/wenyi/e3nk137y/40/embedded/html,js,result" allowfullscreen="allowfullscreen" frameborder="0"></iframe>


<!--
## Data Methods


## Merge Cells


## Check Methods


## Column Methods
-->